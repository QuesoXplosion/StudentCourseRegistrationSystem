<?php

    error_reporting(E_ALL ^ E_NOTICE);
    require_once('Connect.php');
    $myConnection = $newConnection->connection;
    require 'master.php';

    session_start();
    deleteNotifications($myConnection,$_SESSION['studentNum']);
    unset($_SESSION['username']);  
    header("Location: home.php");

    function deleteNotifications($connection,$studentId) {
        $deleteFromNotificationsQuery =  "DELETE FROM notification 
            WHERE studentNum = $studentNum";
        $results = mysqli_query($connection, $deleteFromNotificationsQuery);
    };

?>